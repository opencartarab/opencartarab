<?php
// Text
$_['text_subject'] = 'Reset security code attempts';
$_['text_reset']   = 'Some one entered the security code wrongly more than 3 times.';
$_['text_link']    = 'Click on the link below to reset account security:';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Best Regards';