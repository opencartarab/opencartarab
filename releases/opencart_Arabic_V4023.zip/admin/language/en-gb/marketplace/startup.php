<?php
// Heading
$_['heading_title']     = 'Startup';

// Text
$_['text_success']      = 'Success: You have modified startup!';
$_['text_list']         = 'Startup List';

// Column
$_['column_code']       = 'Startup Code';
$_['column_sort_order'] = 'Sort Order';
$_['column_action']     = 'Action';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify startup!';
