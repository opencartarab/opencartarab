<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']           = 'الأقسام';

// Text
$_['text_success']            = 'تم بنجاح: لقد قمت بتعديل الأقسام!';
$_['text_list']               = 'قائمة الأقسام';
$_['text_add']                = 'إضافة قسم';
$_['text_edit']               = 'تعديل قسم';
$_['text_filter']             = 'فلتر';
$_['text_default']            = 'افتراضي';
$_['text_keyword']            = 'لا تستخدم المسافات، بل استبدلها بعلامة الشرطة - وتأكد من أن كلمة رابط السيو فريد وغير مكرر في المتجر.';

// Column
$_['column_name']             = 'اسم القسم';
$_['column_sort_order']       = 'ترتيب الفرز';
$_['column_action']           = 'تحرير';

// Entry
$_['entry_name']              = 'اسم القسم';
$_['entry_description']       = 'الوصف';
$_['entry_meta_title']        = 'عنوان الميتا تاج';
$_['entry_meta_keyword']      = 'كلمات مفتاحية للميتاج';
$_['entry_meta_description']  = 'وصف الميتا تاج';
$_['entry_store']             = 'المتاجر';
$_['entry_keyword']           = 'الكلمة المفتاحية';
$_['entry_parent']            = 'القسم الرئيسي';
$_['entry_filter']            = 'الفلاتر';
$_['entry_image']             = 'الصورة';
$_['entry_sort_order']        = 'ترتيب الفرز';
$_['entry_status']            = 'الحالة';
$_['entry_layout']            = 'تطبيق التخطيط';

// Help
$_['help_parent']             = '(اكتب بداية حرف أي كلمة لتظهر القائمة المنسدلة للاستكمال التلقائي)';
$_['help_filter']             = '(اكتب بداية حرف أي كلمة لتظهر القائمة المنسدلة للاستكمال التلقائي)';

// Error
$_['error_warning']           = 'تحذير: يرجى التحقق من النموذج بعناية بحثًا عن الأخطاء!';
$_['error_permission']        = 'تحذير: ليس لديك إذن لتعديل الأقسام!';
$_['error_name']              = 'يجب أن يكون اسم القسم بين 1 و 255 حرفًا!';
$_['error_meta_title']        = 'يجب أن يكون عنوان الميتا تاج أكبر من 1 وأقل من 255 حرفًا!';
$_['error_parent']            = 'القسم الرئيسي الذي اخترته هو قسم فرعي من القسم الحالي!';
$_['error_keyword']           = 'يجب أن يكون روابط كلمات السيو بين 1 و 64 حرفًا!';
$_['error_keyword_exists']    = 'يجب أن يكون روابط كلمات السيو فريدة!';
$_['error_keyword_character'] = 'الكلمة المفتاحية يمكن أن تحتوي فقط على الأحرف a-z، 0-9، - و _!';
