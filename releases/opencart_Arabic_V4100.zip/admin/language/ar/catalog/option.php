<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'خيارات المنتجات';

// Text
$_['text_success']       = 'تم بنجاح: لقد قمت بتعديل خيارات المنتجات!';
$_['text_list']          = 'قائمة خيارات المنتجات';
$_['text_add']           = 'إضافة خيار منتج';
$_['text_edit']          = 'تعديل خيار منتج';
$_['text_choose']        = 'اختر';
$_['text_select']        = 'اختيار';
$_['text_radio']         = 'اختيار أحادي';
$_['text_checkbox']      = 'مربع اختيار';
$_['text_input']         = 'إدخال';
$_['text_text']          = 'نص';
$_['text_textarea']      = 'مربع نص';
$_['text_file']          = 'ملف';
$_['text_date']          = 'تاريخ';
$_['text_datetime']      = 'تاريخ ووقت';
$_['text_time']          = 'الوقت';
$_['text_option']        = 'الخيار';
$_['text_value']         = 'قيم الخيارات';

// Column
$_['column_name']        = 'اسم الخيار';
$_['column_sort_order']  = 'ترتيب الفرز';
$_['column_action']      = 'تحرير';

// Entry
$_['entry_name']         = 'اسم الخيار';
$_['entry_type']         = 'النوع';
$_['entry_option_value'] = 'اسم قيمة الخيار';
$_['entry_image']        = 'الصورة';
$_['entry_sort_order']   = 'ترتيب الفرز';

// Error
$_['error_warning']      = 'تحذير: يرجى التحقق من النموذج بعناية بحثًا عن الأخطاء!';
$_['error_permission']   = 'تحذير: ليس لديك إذن لتعديل خيارات المنتجات!';
$_['error_name']         = 'يجب أن يكون اسم الخيار بين 1 و 128 حرفًا!';
$_['error_type']         = 'تحذير: القيم المطلوبة للخيار!';
$_['error_option_value'] = 'يجب أن يكون اسم قيمة الخيار بين 1 و 128 حرفًا!';
$_['error_value']        = 'تحذير: لا يمكن حذف قيمة الخيار هذه لأنها مرتبطة حاليًا بـ %s منتجًا!';
$_['error_product']      = 'تحذير: لا يمكن حذف هذا الخيار لأنه مرتبط حاليًا بـ %s منتجًا!';
