<?php
// Website: WWW.OpenCartArab.com
// E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']        = 'منع الكلمات غير اللائقة';

// Text
$_['text_success']         = 'تم بنجاح: لقد قمت بتعديل منع الكلمات غير اللائقة!';
$_['text_list']            = 'قائمة منع الكلمات غير اللائقة';
$_['text_add']             = 'إضافة كلمة غير لائقة';
$_['text_edit']            = 'تعديل الكلمات غير اللائقة';

// Column
$_['column_keyword']       = 'الكلمة المفتاحية';
$_['column_action']        = 'تحرير';

// Entry
$_['entry_keyword']        = 'الكلمة المفتاحية';

// Error
$_['error_warning']        = 'تحذير: يرجى التحقق من النموذج بعناية للعثور على الأخطاء!';
$_['error_permission']     = 'تحذير: ليس لديك إذن لتعديل منع الكلمات غير اللائقة!';
$_['error_keyword']        = 'يجب أن تكون الكلمة المفتاحية بين 1 و 64 حرفًا!';
$_['error_keyword_exists'] = 'يجب أن تكون الكلمة المفتاحية فريدة!';
