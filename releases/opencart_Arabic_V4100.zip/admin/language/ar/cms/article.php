<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']           = 'المقالات';

// Text
$_['text_success']            = 'تم بنجاح: لقد قمت بتعديل المقالات!';
$_['text_next']               = 'تم بنجاح: لقد قمت بتعديل %s إلى %s من %s تقييمات المقالات!';
$_['text_list']               = 'قائمة المقالات';
$_['text_add']                = 'إضافة مقال';
$_['text_edit']               = 'تعديل مقال';
$_['text_default']            = 'الافتراضي';
$_['text_keyword']            = 'لا تستخدم المسافات، بل استبدلها بعلامة الشرطة - وتأكد من أن كلمة رابط السيو فريد وغير مكرر في المتجر.';

// Column
$_['column_name']             = 'اسم المقال';
$_['column_author']           = 'المؤلف';
$_['column_rating']           = 'التقييم';
$_['column_date_added']       = 'تاريخ الإضافة';
$_['column_action']           = 'تحرير';

// Entry
$_['entry_image']             = 'الصورة';
$_['entry_name']              = 'اسم المقال';
$_['entry_description']       = 'الوصف';
$_['entry_tag']               = 'الوسوم';
$_['entry_meta_title']        = 'عنوان الوسم التعريفي';
$_['entry_meta_keyword']      = 'كلمات الوسم التعريفية';
$_['entry_meta_description']  = 'وصف الوسم التعريفي';
$_['entry_topic']             = 'الموضوع';
$_['entry_author']            = 'المؤلف';
$_['entry_store']             = 'المتاجر';
$_['entry_sort_order']        = 'ترتيب الفرز';
$_['entry_status']            = 'الحالة';
$_['entry_keyword']           = 'روابط السيو';
$_['entry_layout']            = 'تطبيق التصميم';

// Button
$_['button_rating']           = 'حساب التقييمات';

// Error
$_['error_warning']           = 'تحذير: يرجى التحقق من النموذج بعناية بحثًا عن الأخطاء!';
$_['error_permission']        = 'تحذير: ليس لديك إذن بتعديل المقالات!';
$_['error_name']              = 'يجب أن يكون اسم المقال بين 1 و 255 حرفًا!';
$_['error_meta_title']        = 'يجب أن يكون العنوان التعريفي أكبر من 1 وأقل من 255 حرفًا!';
$_['error_keyword']           = 'يجب أن يكون رابط السيو بين 1 و 64 حرفًا!';
$_['error_keyword_exists']    = 'يجب أن يكون رابط السيو فريدًا!';
$_['error_keyword_character'] = 'يمكن أن تحتوي روابط السيو فقط على الأحرف a-z، الأرقام 0-9، والرمزين - و _!';
$_['error_author']            = 'يجب أن يكون اسم المؤلف بين 3 و 64 حرفًا!';