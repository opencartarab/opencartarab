<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']           = 'المواضيع';

// Text
$_['text_success']            = 'تم التعديل بنجاح: تم تعديل المواضيع!';
$_['text_list']               = 'قائمة المواضيع';
$_['text_add']                = 'إضافة موضوع';
$_['text_edit']               = 'تعديل موضوع';
$_['text_default']            = 'افتراضي';
$_['text_keyword']            = 'لا تستخدم المسافات، بل استبدلها بـ - وتأكد من أن روابط كلمات السيو فريدة من نوعها وغير مكررة في المتجر.';

// Column
$_['column_name']             = 'اسم الموضوع';
$_['column_sort_order']       = 'ترتيب الفرز';
$_['column_action']           = 'تحرير';

// Entry
$_['entry_image']             = 'صورة';
$_['entry_name']              = 'اسم الموضوع';
$_['entry_description']       = 'الوصف';
$_['entry_meta_title']        = 'عنوان ميتا تاج';
$_['entry_meta_keyword']      = 'كلمات ميتا تاج الرئيسية';
$_['entry_meta_description']  = 'وصف ميتا تاج';
$_['entry_store']             = 'المتاجر';
$_['entry_sort_order']        = 'ترتيب الفرز';
$_['entry_status']            = 'الحالة';
$_['entry_keyword']           = 'روابط السيو';

// Error
$_['error_warning']           = 'تحذير: من فضلك تحقق من النموذج بعناية للبحث عن الأخطاء!';
$_['error_permission']        = 'تحذير: ليس لديك صلاحية لتعديل المواضيع!';
$_['error_name']              = 'يجب أن يكون اسم الموضوع بين 1 و 255 حرفًا!';
$_['error_meta_title']        = 'يجب أن يكون عنوان الميتا أكبر من 1 وأقل من 255 حرفًا!';
$_['error_keyword']           = 'يجب أن يكون SEO URL بين 1 و 64 حرفًا!';
$_['error_keyword_exists']    = 'يجب أن يكون SEO URL فريدًا!';
$_['error_keyword_character'] = 'يمكن لرابط السيو استخدام الحروف من a-z، 0-9، - و _ فقط!';