<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']          = 'خيارات المطور';

// Text
$_['text_developer_success'] = 'تم التعديل بنجاح: تم تعديل إعدادات المطور!';
$_['text_cache_success']     = 'تم التعديل بنجاح: تم مسح الذاكرة المؤقتة!';
$_['text_theme_success']     = 'تم التعديل بنجاح: تم مسح ذاكرة التخزين المؤقتة للقالب!';
$_['text_sass_success']      = 'تم التعديل بنجاح: تم مسح ذاكرة التخزين المؤقتة لـ SASS!';
$_['text_vendor_success']    = 'تم التعديل بنجاح: تم مسح ذاكرة التخزين المؤقتة للبائع!';
$_['text_theme']             = 'القالب';
$_['text_sass']              = 'SASS';
$_['text_cache']             = 'الذاكرة المؤقتة';
$_['text_vendor']            = 'Vendor';

// Column
$_['column_component']       = 'المكون';
$_['column_action']          = 'تحرير';

// Entry
$_['entry_cache']            = 'الذاكرة المؤقتة';

// Buttons
$_['button_on']              = 'تشغيل';
$_['button_off']             = 'إيقاف';

// Error
$_['error_permission']       = 'تحذير: ليس لديك صلاحية لتعديل إعدادات المطور!';

