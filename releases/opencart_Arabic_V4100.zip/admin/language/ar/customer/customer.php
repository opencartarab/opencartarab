<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']         = 'العملاء';

// Text
$_['text_success']          = 'تم التعديل بنجاح: تم تعديل العملاء!';
$_['text_list']             = 'قائمة العملاء';
$_['text_add']              = 'إضافة عميل';
$_['text_edit']             = 'تعديل عميل';
$_['text_default']          = 'افتراضي';
$_['text_store']            = 'المتجر';
$_['text_customer']         = 'تفاصيل العميل';
$_['text_password']         = 'كلمة المرور';
$_['text_other']            = 'أخرى';
$_['text_balance']          = 'الرصيد';
$_['text_address']          = 'العناوين';
$_['text_address_add']      = 'إضافة عنوان';
$_['text_address_edit']     = 'تعديل عنوان';
$_['text_payment_method']   = 'طرق الدفع';
$_['text_history']          = 'التاريخ';
$_['text_history_add']      = 'إضافة تاريخ';
$_['text_transaction']      = 'المعاملات';
$_['text_transaction_add']  = 'إضافة معاملة';
$_['text_reward']           = 'نقاط المكافأة';
$_['text_reward_add']       = 'إضافة نقاط مكافأة';
$_['text_ip']               = 'تاريخ الـ IP';
$_['text_authorize']        = 'تاريخ التفويض';
$_['text_option']           = 'الخيارات';
$_['text_login']            = 'تسجيل الدخول إلى المتجر';
$_['text_unlock']           = 'فتح الحساب';
$_['text_filter']           = 'تصفية';

// Column
$_['column_name']           = 'اسم العميل';
$_['column_email']          = 'البريد الإلكتروني';
$_['column_customer_group'] = 'مجموعة العملاء';
$_['column_status']         = 'الحالة';
$_['column_date_added']     = 'تاريخ الإضافة';
$_['column_comment']        = 'التعليق';
$_['column_description']    = 'الوصف';
$_['column_amount']         = 'المبلغ';
$_['column_points']         = 'النقاط';
$_['column_ip']             = 'الـ IP';
$_['column_account']        = 'الحسابات';
$_['column_store']          = 'المتجر';
$_['column_country']        = 'البلد';
$_['column_payment_method'] = 'اسم الدفع';
$_['column_image']          = 'الصورة';
$_['column_type']           = 'النوع';
$_['column_date_expire']    = 'تاريخ الانتهاء';
$_['column_user_agent']     = 'وكيل المستخدم';
$_['column_address']        = 'العنوان';
$_['column_action']         = 'تحرير';

// Entry
$_['entry_store']           = 'المتجر';
$_['entry_language']        = 'اللغة';
$_['entry_customer_group']  = 'مجموعة العملاء';
$_['entry_firstname']       = 'الاسم الأول';
$_['entry_lastname']        = 'الاسم الأخير';
$_['entry_email']           = 'البريد الإلكتروني';
$_['entry_telephone']       = 'رقم التواصل';
$_['entry_newsletter']      = 'النشرة الإخبارية';
$_['entry_status']          = 'الحالة';
$_['entry_safe']            = 'آمن';
$_['entry_commenter']       = 'المعلق';
$_['entry_password']        = 'كلمة المرور';
$_['entry_confirm']         = 'تأكيد كلمة المرور';
$_['entry_company']         = 'الشركة';
$_['entry_address_1']       = 'العنوان 1';
$_['entry_address_2']       = 'العنوان 2';
$_['entry_city']            = 'المدينة';
$_['entry_postcode']        = 'الرمز البريدي';
$_['entry_country']         = 'البلد';
$_['entry_zone']            = 'المنطقة / الدولة';
$_['entry_default']         = 'افتراضي';
$_['entry_comment']         = 'التعليق';
$_['entry_description']     = 'الوصف';
$_['entry_amount']          = 'المبلغ';
$_['entry_points']          = 'النقاط';
$_['entry_name']            = 'اسم العميل';
$_['entry_ip']              = 'الـ IP';
$_['entry_date_from']       = 'التاريخ من';
$_['entry_date_to']         = 'التاريخ إلى';

// Tab
$_['tab_authorize']         = 'التفويض';

// Button
$_['button_order']          = 'الطلبات';

// Help
$_['help_safe']             = 'ضعها على "نعم" لتجنب أن يتم الحظر على هذا العميل بواسطة نظام مكافحة الاحتيال';
$_['help_commenter']        = 'ضعها على "نعم" للسماح للعميل أن يتم رصده بواسطة نظام مكافحة السبام';
$_['help_points']           = 'استخدم علامة الناصص لإزالة النقاط';

// Error
$_['error_warning']         = 'تحذير: الرجاء فحص النموذج بعناية للبحث عن الأخطاء!';
$_['error_permission']      = 'تحذير: ليس لديك صلاحية لتعديل العملاء!';
$_['error_customer']        = 'تحذير: العميل غير موجود!';
$_['error_exists']          = 'تحذير: عنوان البريد الإلكتروني مسجل بالفعل!';
$_['error_address']         = 'تحذير: العنوان غير موجود!';
$_['error_firstname']       = 'الاسم الأول يجب أن يكون بين 1 و 32 حرفًا!';
$_['error_lastname']        = 'الاسم الأخير يجب أن يكون بين 1 و 32 حرفًا!';
$_['error_email']           = 'عنوان البريد الإلكتروني لا يبدو صالحًا!';
$_['error_telephone']       = 'رقم التواصل يجب أن يكون بين 3 و 32 حرفًا!';
$_['error_password']        = 'كلمة المرور يجب أن تكون بين 6 و 20 حرفًا!';
$_['error_confirm']         = 'كلمة المرور وتأكيد كلمة المرور غير متطابقين!';
$_['error_address_1']       = 'العنوان 1 يجب أن يكون بين 3 و 128 حرفًا!';
$_['error_city']            = 'المدينة يجب أن تكون بين 2 و 128 حرفًا!';
$_['error_postcode']        = 'الرمز البريدي يجب أن يكون بين 2 و 10 أحرف لهذا البلد!';
$_['error_country']         = 'الرجاء اختيار البلد!';
$_['error_zone']            = 'الرجاء اختيار المنطقة / الدولة!';
$_['error_custom_field']    = '%s مطلوب!';
$_['error_regex']           = '%s ليس إدخالًا صالحًا!';
