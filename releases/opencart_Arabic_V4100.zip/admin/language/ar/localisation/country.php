<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']           = 'الدول';

// Text
$_['text_success']            = 'تم: تم تعديل الدول بنجاح!';
$_['text_list']               = 'قائمة الدول';
$_['text_add']                = 'إضافة دولة';
$_['text_edit']               = 'تعديل دولة';
$_['text_filter']             = 'تصفية';

// Column
$_['column_name']             = 'اسم الدولة';
$_['column_iso_code_2']       = 'كود ISO (2)';
$_['column_iso_code_3']       = 'كود ISO (3)';
$_['column_action']           = 'تحرير';

// Entry
$_['entry_name']              = 'اسم الدولة';
$_['entry_iso_code_2']        = 'كود ISO (2)';
$_['entry_iso_code_3']        = 'كود ISO (3)';
$_['entry_address_format']    = 'تنسيق العنوان';
$_['entry_postcode_required'] = 'رمز البريد مطلوب';
$_['entry_status']            = 'الحالة';

// Error
$_['error_permission']        = 'تحذير: ليس لديك إذن لتعديل الدول!';
$_['error_name']              = 'اسم الدولة يجب أن يكون بين 1 و 128 حرفًا!';
$_['error_iso_code_2']        = 'كود ISO 2 يجب أن يكون مكونًا من حرفين!';
$_['error_iso_code_3']        = 'كود ISO 3 يجب أن يكون مكونًا من 3 أحرف!';
$_['error_default']           = 'تحذير: لا يمكن حذف هذه الدولة لأنها تم تعيينها حاليًا كدولة المتجر الافتراضية!';
$_['error_store']             = 'تحذير: لا يمكن حذف هذه الدولة لأنها تم تعيينها حاليًا إلى %s متاجر!';
$_['error_address']           = 'تحذير: لا يمكن حذف هذه الدولة لأنها تم تعيينها حاليًا إلى %s مدخلات دفتر العناوين!';
$_['error_zone']              = 'تحذير: لا يمكن حذف هذه الدولة لأنها تم تعيينها حاليًا إلى %s مناطق!';
$_['error_zone_to_geo_zone']  = 'تحذير: لا يمكن حذف هذه الدولة لأنها تم تعيينها حاليًا إلى %s مناطق إلى المناطق الجغرافية!';

