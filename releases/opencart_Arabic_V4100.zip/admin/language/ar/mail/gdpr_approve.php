<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject'] = '%s - تم الموافقة على طلب الـ GDPR!';
$_['text_request'] = 'طلب حذف الحساب';
$_['text_hello']   = 'مرحبًا <strong>%s</strong>,';
$_['text_user']    = 'المستخدم';
$_['text_gdpr']    = 'تمت الموافقة على طلب حذف بيانات الـ GDPR الخاصة بك، وسيتم حذفها خلال <strong>%s يومًا</strong>.';
$_['text_q']       = 'س. لماذا لا نحذف بياناتك على الفور؟';
$_['text_a']       = 'ج. سيتم معالجة طلبات حذف الحساب بعد <strong>%s يومًا</strong> حتى يمكن معالجة أي استرداد أو استرجاع أموال أو اكتشاف الاحتيال.';
$_['text_delete']  = 'ستتلقى بريدًا إلكترونيًا يُعلمك عند حذف حسابك.';
$_['text_thanks']  = 'شكرًا,';
