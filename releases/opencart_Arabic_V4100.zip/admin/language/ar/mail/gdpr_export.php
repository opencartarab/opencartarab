<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']    = '%s - تم استكمال طلب تصدير بيانات الـ GDPR!';
$_['text_request']    = 'تصدير البيانات الشخصية';
$_['text_hello']      = 'مرحبًا <strong>%s</strong>,';
$_['text_user']       = 'المستخدم';
$_['text_gdpr']       = 'تم الآن إتمام طلب بيانات الـ GDPR الخاصة بك. ستجد أدناه بيانات الـ GDPR الخاصة بك.';
$_['text_account']    = 'الحساب';
$_['text_customer']   = 'المعلومات الشخصية';
$_['text_address']    = 'العنوان';
$_['text_addresses']  = 'العناوين';
$_['text_name']       = 'اسم العميل';
$_['text_recipient']  = 'المستلم';
$_['text_email']      = 'البريد الإلكتروني';
$_['text_telephone']  = 'رقم التواصل';
$_['text_company']    = 'الشركة';
$_['text_address_1']  = 'العنوان 1';
$_['text_address_2']  = 'العنوان 2';
$_['text_postcode']   = 'الرمز البريدي';
$_['text_city']       = 'المدينة';
$_['text_country']    = 'الدولة';
$_['text_zone']       = 'المنطقة / المحافظة';
$_['text_history']    = 'سجل الدخول';
$_['text_ip']         = 'عنوان الـ IP';
$_['text_date_added'] = 'تاريخ الإضافة';
$_['text_thanks']     = 'شكرًا,';
