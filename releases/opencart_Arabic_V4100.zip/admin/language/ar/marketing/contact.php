<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']        = 'البريد الإلكتروني';

// Text
$_['text_mail']            = 'إرسال رسائل البريد الإلكتروني للعملاء';
$_['text_success']         = 'تم إرسال رسالتك بنجاح!';
$_['text_sent']            = 'تم إرسال رسالتك بنجاح إلى %s من %s مستلمين!';
$_['text_default']         = 'الافتراضي';
$_['text_newsletter']      = 'جميع المشتركين في النشرة الإخبارية';
$_['text_customer_all']    = 'جميع العملاء';
$_['text_customer_group']  = 'مجموعة العملاء';
$_['text_customer']        = 'العملاء';
$_['text_affiliate_all']   = 'جميع المسوقين بالعمولة';
$_['text_affiliate']       = 'المسوقون بالعمولة';
$_['text_product']         = 'المنتجات';

// Entry
$_['entry_store']          = 'من';
$_['entry_to']             = 'إلى';
$_['entry_customer_group'] = 'مجموعة العملاء';
$_['entry_customer']       = 'العميل';
$_['entry_affiliate']      = 'المسوق بالعمولة';
$_['entry_product']        = 'المنتجات';
$_['entry_subject']        = 'الموضوع';
$_['entry_message']        = 'الرسالة';

// Help
$_['help_customer']        = '(إكمال تلقائي)';
$_['help_affiliate']       = '(إكمال تلقائي)';
$_['help_product']         = 'إرسال فقط للعملاء الذين قاموا بطلب منتجات في القائمة. (إكمال تلقائي)';

// Error
$_['error_permission']     = 'تحذير: ليس لديك إذن لإرسال رسائل البريد الإلكتروني!';
$_['error_subject']        = 'الموضوع مطلوب!';
$_['error_message']        = 'الرسالة مطلوبة!';
$_['error_email']          = 'لا يوجد مستلمون للبريد الإلكتروني!';

