<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'الأحداث البرمجية';

// Text
$_['text_success']      = 'تم بنجاح: لقد قمت بتعديل الأحداث البرمجية!';
$_['text_list']         = 'قائمة الأحداث البرمجية';
$_['text_event']        = 'تُستخدم الأحداث البرمجية من قبل الإضافات لتجاوز الوظائف الافتراضية لمتجرك. إذا واجهت مشاكل يمكنك تعطيل أو تمكين الأحداث البرمجية هنا.';
$_['text_info']         = 'معلومات الحدث البرمجي';

// Column
$_['column_code']       = 'كود الحدث البرمجي';
$_['column_sort_order'] = 'ترتيب الفرز';
$_['column_action']     = 'الإجراء';

// Entry
$_['entry_description'] = 'الوصف';
$_['entry_trigger']     = 'المحفز - Trigger';
$_['entry_action']      = 'الحدث - Action';

// Error
$_['error_permission']  = 'تحذير: ليس لديك إذن لتعديل الأحداث البرمجية!';

