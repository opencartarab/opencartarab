<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']          = 'مثبت الإضافات';

// Text
$_['text_upload']            = 'تم بنجاح: تم رفع الإضافة!';
$_['text_success']           = 'تم بنجاح: لقد قمت بتعديل الإضافات!';
$_['text_progress']          = 'تقدم التثبيت';
$_['text_installed']         = 'الإضافات المثبتة';
$_['text_info']              = 'معلومات الإضافة';
$_['text_install']           = 'تثبيت الملفات %s إلى %s من %s';
$_['text_vendor']            = 'تحديث ملفات المورد';
$_['text_xml']               = 'تثبيت ملفات OCMOD';

// Column
$_['column_image']           = 'الصورة';
$_['column_name']            = 'اسم الإضافة';
$_['column_version']         = 'الإصدار';
$_['column_date_added']      = 'تاريخ الإضافة';
$_['column_action']          = 'الإجراء';

// Entry
$_['entry_progress']         = 'التقدم';
$_['entry_name']             = 'اسم الإضافة';
$_['entry_description']      = 'الوصف';
$_['entry_code']             = 'الكود';

// Error
$_['error_permission']       = 'تحذير: ليس لديك إذن لتعديل الإضافات!';
$_['error_install']          = 'تحذير: لم يتم العثور على ملف install.json!';
$_['error_default']          = 'لا يمكن إلغاء تثبيت أو حذف الإضافة الافتراضية!';
$_['error_extension']        = 'لا يمكن العثور على الإضافة المثبتة!';
$_['error_installed']        = 'الإضافة تم تثبيتها بالفعل!';
$_['error_uninstall']        = 'هناك %s إضافات يجب إلغاء تثبيتها قبل إزالة هذه الإضافة بشكل آمن!';
$_['error_name']             = 'يجب أن يكون الاسم بين 3 و 128 حرفاً!';
$_['error_version']          = 'يجب أن يكون الإصدار بين 3 و 128 حرفاً!';
$_['error_author']           = 'يجب أن يكون المؤلف بين 3 و 128 حرفاً!';
$_['error_link']             = 'يجب أن يكون الرابط بين 3 و 128 حرفاً!';
$_['error_filename']         = 'يجب أن يكون اسم الملف بين 3 و 128 حرفاً!';
$_['error_file']             = 'لم يتم العثور على ملف التثبيت %s!';
$_['error_file_exists']      = 'الملف موجود بالفعل!';
$_['error_file_type']        = 'نوع الملف غير صالح!';
$_['error_directory']        = 'لم يتم العثور على دليل التثبيت %s!';
$_['error_directory_exists'] = 'المسار %s موجود بالفعل!';
$_['error_unzip']            = 'لم يتم فتح ملف Zip!';
$_['error_upload']           = 'لم يتم رفع الملف!';
