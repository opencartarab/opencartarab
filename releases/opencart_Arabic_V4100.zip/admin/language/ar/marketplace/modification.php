<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'التعديلات البرمجية';

// Text
$_['text_success']      = 'تم بنجاح: لقد قمت بتعديل التعديلات البرمجية!';
$_['text_refresh']      = 'كلما قمت بتمكين / تعطيل أو حذف تعديل برمجي، يجب عليك النقر على زر التحديث لإعادة بناء ذاكرة التعديل!';
$_['text_list']         = 'قائمة التعديلات البرمجية';
$_['text_info']         = 'معلومات التعديل البرمجي';

// Column
$_['column_name']       = 'اسم التعديل البرمجي';
$_['column_author']     = 'المؤلف';
$_['column_version']    = 'الإصدار';
$_['column_status']     = 'الحالة';
$_['column_date_added'] = 'تاريخ الإضافة';
$_['column_action']     = 'الإجراء';

// Entry
$_['entry_name']        = 'اسم التعديل البرمجي';
$_['entry_description'] = 'الوصف';
$_['entry_code']        = 'الكود';
$_['entry_xml']         = 'XML';

// Error
$_['error_permission']  = 'تحذير: ليس لديك إذن لتعديل التعديلات البرمجية!';
