<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'إعداد النظام';

// Text
$_['text_success']      = 'تم بنجاح: لقد قمت بتعديل إعدادات النظام!';
$_['text_list']         = 'قائمة إعداد النظام';
$_['text_info']         = 'معلومات إعداد النظام';

// Column
$_['column_code']       = 'كود إعداد النظام';
$_['column_sort_order'] = 'ترتيب العرض';
$_['column_action']     = 'الإجراء';

// Entry
$_['entry_description'] = 'الوصف';

// Error
$_['error_permission']  = 'تحذير: ليس لديك إذن لتعديل إعدادات النظام!';

