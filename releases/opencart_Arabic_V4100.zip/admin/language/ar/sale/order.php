<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']              = 'الطلبات';

// Text
$_['text_success']               = 'تم بنجاح: لقد قمت بتعديل الطلبات!';
$_['text_list']                  = 'قائمة الطلبات';
$_['text_add']                   = 'إضافة طلب';
$_['text_edit']                  = 'رقم الطلب (#%s)';
$_['text_filter']                = 'تصفية';
$_['text_store']                 = 'المتجر';
$_['text_date_added']            = 'تاريخ الإضافة';
$_['text_customer']              = 'العميل';
$_['text_product_add']           = 'إضافة منتج';
$_['text_model'] 			     = 'الطراز';
$_['text_reward']                = 'نقاط المكافأة';
$_['text_points']                = 'النقاط';
$_['text_reward_add']            = 'تم بنجاح: تم إضافة نقاط المكافأة!';
$_['text_reward_remove']         = 'تم بنجاح: تم إزالة نقاط المكافأة!';
$_['text_affiliate']             = 'شريك التسويق';
$_['text_commission']            = 'العمولة';
$_['text_commission_add']        = 'تم بنجاح: تم إضافة العمولة!';
$_['text_commission_remove']     = 'تم بنجاح: تم إزالة العمولة!';
$_['text_upload']                = 'تم رفع الملف بنجاح!';
$_['text_subscription']          = 'الاشتراك';
$_['text_subscription_trial']    = '%s كل %d %s(s) لمدة %d دفعة(s) ثم ';
$_['text_subscription_duration'] = '%s كل %d %s(s) لمدة %d دفعة(s)';
$_['text_subscription_cancel']   = '%s كل %d %s(s) حتى يتم الإلغاء';
$_['text_day']                   = 'يوم';
$_['text_week']                  = 'أسبوع';
$_['text_semi_month']            = 'نصف شهر';
$_['text_month']                 = 'شهر';
$_['text_year']                  = 'سنة';
$_['text_more']                  = 'المزيد..';
$_['text_less']                  = 'أقل..';
$_['text_payment_address']       = 'عنوان الدفع';
$_['text_payment_method']        = 'طريقة الدفع';
$_['text_payment']               = 'الرجاء اختيار طريقة الدفع المفضلة لاستخدامها في هذا الطلب.';
$_['text_shipping_address']      = 'عنوان الشحن';
$_['text_shipping_method']       = 'طريقة الشحن';
$_['text_shipping']              = 'الرجاء اختيار طريقة الشحن المفضلة لاستخدامها في هذا الطلب.';
$_['text_comment']               = 'ملاحظات العميل على الطلب';
$_['text_history']               = 'تتبع حالة الطلب';
$_['text_history_add']           = 'تغيير حالة للطلب';
$_['text_browser']               = 'المتصفح';
$_['text_ip']                    = 'عنوان الـ IP';
$_['text_forwarded_ip']          = 'IP محول';
$_['text_user_agent']            = 'وكيل المستخدم';
$_['text_accept_language']       = 'اللغة المختارة عند الطلب';
$_['text_order_id']              = 'رقم الطلب';
$_['text_website']               = 'الموقع الإلكتروني';
$_['text_invoice']               = 'الفاتورة';
$_['text_invoice_no']            = 'رقم الفاتورة';
$_['text_tbc']                   = 'لم يتم تحديده';
$_['text_store_address']         = 'عنوان المتجر';
$_['text_store_telephone']       = 'رقم تواصل المتجر';
$_['text_store_email']           = 'بريد المتجر الإلكتروني';
$_['text_customer_email']        = 'بريد العميل الإلكتروني';
$_['text_customer_telephone']    = 'رقم التواصل للعميل';
$_['text_missing']               = 'الطلبات المفقودة';
$_['text_default']               = 'افتراضي';
$_['text_picklist']              = 'مذكرة الشحن';

// Column
$_['column_order_id']            = 'رقم الطلب';
$_['column_customer']            = 'العميل';
$_['column_store']               = 'المتجر';
$_['column_status']              = 'الحالة';
$_['column_date_added']          = 'تاريخ الإضافة';
$_['column_date_modified']       = 'تاريخ التعديل';
$_['column_total']               = 'الإجمالي';
$_['column_product']             = 'المنتج';
$_['column_model']               = 'الطراز';
$_['column_quantity']            = 'الكمية';
$_['column_price']               = 'السعر لكل وحدة';
$_['column_comment']             = 'ملاحظات اضافية';
$_['column_notify']              = 'تم إعلام العميل';
$_['column_location']            = 'الموقع';
$_['column_reference']           = 'المرجع';
$_['column_weight']              = 'وزن المنتج';
$_['column_action']              = 'تحرير';

// Entry
$_['entry_store']                = 'المتجر';
$_['entry_customer']             = 'العميل';
$_['entry_customer_group']       = 'مجموعة العميل';
$_['entry_firstname']            = 'الاسم الأول';
$_['entry_lastname']             = 'الاسم الأخير';
$_['entry_email']                = 'البريد الإلكتروني';
$_['entry_telephone']            = 'رقم التواصل';
$_['entry_address']              = 'اختر العنوان';
$_['entry_company']              = 'الشركة';
$_['entry_address_1']            = 'العنوان 1';
$_['entry_address_2']            = 'العنوان 2';
$_['entry_city']                 = 'المدينة';
$_['entry_postcode']             = 'الرمز البريدي';
$_['entry_country']              = 'الدولة';
$_['entry_zone']                 = 'المنطقة / المحافظة';
$_['entry_product']              = 'اختر المنتج';
$_['entry_option']               = 'اختر الخيارات';
$_['entry_subscription']         = 'اختر الاشتراك';
$_['entry_quantity']             = 'الكمية';
$_['entry_order_status']         = 'حالة الطلب';
$_['entry_notify']               = 'إشعار العميل';
$_['entry_shipping_method']      = 'طريقة الشحن';
$_['entry_payment_method']       = 'طريقة الدفع';
$_['entry_override']             = 'تجاوز';
$_['entry_comment']              = 'ملاحظات';
$_['entry_language']             = 'اللغة';
$_['entry_currency']             = 'العملة';
$_['entry_affiliate']            = 'شريك التسويق';
$_['entry_order_id']             = 'رقم الطلب';
$_['entry_total']                = 'الإجمالي';
$_['entry_date_from']            = 'التاريخ من';
$_['entry_date_to']              = 'التاريخ إلى';

// Help
$_['help_override']              = 'إذا تم حظر تغيير حالة الطلب بسبب امتداد مكافحة الاحتيال، يمكنك تمكين التجاوز.';

// Error
$_['error_warning']              = 'تحذير: يرجى التحقق من النموذج بعناية بحثًا عن الأخطاء!';
$_['error_permission']           = 'تحذير: ليس لديك إذن لتعديل الطلبات!';
$_['error_invoice_no']           = 'تحذير: رقم الفاتورة تم إنشاؤه بالفعل!';
$_['error_order']                = 'تحذير: الطلب غير موجود!';
$_['error_affiliate']            = 'تحذير: شريك التسويق غير موجود!';
$_['error_reward_add']           = 'تحذير: تم إضافة نقاط المكافأة لهذا الطلب بالفعل!';
$_['error_reward_guest']         = 'تحذير: لا يمكن للزوار استخدام نقاط المكافأة!';
$_['error_commission_add']       = 'تحذير: تم إضافة عمولة شريك التسويق لهذا الطلب بالفعل!';

