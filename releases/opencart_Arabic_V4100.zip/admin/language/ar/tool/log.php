<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'تقرير الأخطاء';

// Text
$_['text_success']     = 'تم تنظيف ملف تقرير الأخطاء !';
$_['text_list']        = 'قائمة';

// Error
$_['error_permission'] = 'تحذير: أنت لا تمتلك الصلاحيات لحذف ملف تقارير الأخطاء!';
$_['error_file']       = 'تحذير: %s تعذر العثور على الملف!';
$_['error_size']       = 'تحذير: ملف سجل الأخطاء %s هو %s!';
$_['error_empty']      = 'تحذير: ملف سجل الأخطاء %s فارغ !';
