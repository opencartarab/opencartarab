<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'مجموعات مديري المتجر';

// Text
$_['text_success']     = 'نجاح: لقد قمت بتعديل مجموعات مديري المتجر!';
$_['text_list']        = 'مجموعة المدير';
$_['text_add']         = 'إضافة مجموعة مدير متجر';
$_['text_edit']        = 'تعديل مجموعة مدير متجر';
$_['text_access']      = 'صلاحيات الدخول';
$_['text_modify']      = 'صلاحيات التعديل';

// Column
$_['column_name']      = 'اسم مجموعة المدير';
$_['column_action']    = 'تحرير';

// Entry
$_['entry_name']       = 'اسم مجموعة المدير';
$_['entry_permission'] = 'الصلاحيات';
$_['entry_extension']  = 'الإضافات';

// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن لتعديل مجموعات مديري المتجر!';
$_['error_name']       = 'اسم مجموعة المدير يجب أن يكون بين 3 و 64 حرفًا!';
$_['error_user']       = 'تحذير: لا يمكن حذف هذه المجموعة لأنها مخصصة حاليًا لـ %s من مديري المتجر!';

