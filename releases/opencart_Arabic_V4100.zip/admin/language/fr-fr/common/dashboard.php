<?php
// Heading
$_['heading_title'] = 'Tableau de Bord';
