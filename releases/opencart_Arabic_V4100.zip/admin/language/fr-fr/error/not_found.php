<?php
// Heading
$_['heading_title']  = 'Page Introuvable!';

// Text
$_['text_not_found'] = 'La page que vous recherchez est introuvable! Veuillez contacter votre administrateur si le problème persiste.';
