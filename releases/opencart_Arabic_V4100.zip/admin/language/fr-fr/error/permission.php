<?php
// Heading
$_['heading_title']   = 'Permission Refusée!';

// Text
$_['text_permission'] = 'Vous n\'avez pas la permission d\'accéder à cette page, veuillez';
