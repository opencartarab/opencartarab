<?php
// Heading
$_['heading_title']    = 'Analyses';

// Text
$_['text_success']     = 'Succès: Vous avez modifié les analyses!';
$_['text_list']        = 'Liste des analyses';

// Column
$_['column_name']      = 'Nom de l\'analyse';
$_['column_status']    = 'Statut';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier les analyses!';
$_['error_extension']  = 'Attention: L\'extension n\'existe pas!';
