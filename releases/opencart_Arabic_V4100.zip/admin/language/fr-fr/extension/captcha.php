<?php
// Heading
$_['heading_title']    = 'Captchas';

// Text
$_['text_success']     = 'Succès: Vous avez modifié les captchas!';
$_['text_list']        = 'Liste des Captchas';

// Column
$_['column_name']      = 'Nom du Captcha';
$_['column_status']    = 'Statut';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas l\'autorisation de modifier les captchas!';
$_['error_extension']  = 'Attention: L\'extension n\'existe pas!';
