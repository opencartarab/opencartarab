<?php
// Heading
$_['heading_title']    = 'Taux de Change';

// Text
$_['text_success']     = 'Succès: Vous avez modifié les taux de change!';
$_['text_list']        = 'Liste des Taux de Change';

// Column
$_['column_name']      = 'Nom du Taux de Change';
$_['column_status']    = 'Statut';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier les taux de change!';
$_['error_extension']  = 'Attention: L\'extension n\'existe pas!';
