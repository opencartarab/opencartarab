<?php
// Titre de l'en-tête
$_['heading_title'] = 'Promotion';
