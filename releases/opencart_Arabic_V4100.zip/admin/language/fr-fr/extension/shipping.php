<?php
// En-tête
$_['heading_title']     = 'Livraison';

// Texte
$_['text_success']      = 'Succès: Vous avez modifié les méthodes de livraison!';
$_['text_list']         = 'Liste des méthodes de livraison';

// Colonne
$_['column_name']       = 'Méthode de livraison';
$_['column_status']     = 'Statut';
$_['column_sort_order'] = 'Ordre de tri';
$_['column_action']     = 'Action';

// Erreur
$_['error_permission']  = 'Attention: Vous n\'avez pas la permission de modifier les méthodes de livraison!';
$_['error_extension']   = 'Attention: L\'extension n\'existe pas!';
