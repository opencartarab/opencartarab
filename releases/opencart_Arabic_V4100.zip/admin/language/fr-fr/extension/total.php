<?php
// En-tête
$_['heading_title']     = 'Totaux de Commande';

// Texte
$_['text_success']      = 'Succès: Vous avez modifié les totaux!';

// Colonne
$_['column_name']       = 'Totaux de Commande';
$_['column_status']     = 'Statut';
$_['column_sort_order'] = 'Ordre de Tri';
$_['column_action']     = 'Action';

// Erreur
$_['error_permission']  = 'Attention: Vous n\'avez pas la permission de modifier les totaux!';
$_['error_extension']   = 'Attention: L\'extension n\'existe pas!';
