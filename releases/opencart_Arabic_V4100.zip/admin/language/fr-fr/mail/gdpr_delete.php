<?php
// Texte
$_['text_subject']   = '%s - La demande RGPD a été traitée!';
$_['text_request']   = 'Demande de suppression de compte';
$_['text_hello']     = 'Bonjour <strong>%s</strong>,';
$_['text_user']      = 'Utilisateur';
$_['text_delete']    = 'Votre demande de suppression de données RGPD a été complétée.';
$_['text_contact']   = 'Pour plus d\'informations, vous pouvez contacter le propriétaire de la boutique ici:';
$_['text_thanks']    = 'Merci,';

// Bouton
$_['button_contact'] = 'Contactez-nous';
