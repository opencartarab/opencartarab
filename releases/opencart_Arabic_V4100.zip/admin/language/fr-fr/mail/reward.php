<?php
// Texte
$_['text_subject']  = '%s - Points de Récompense';
$_['text_received'] = 'Vous avez reçu %s points de récompense!';
$_['text_total']    = 'Votre total de points de récompense est maintenant de %s.';
