<?php
// Heading
$_['heading_title']    = 'Notifications';

// Text
$_['text_success']     = 'Succès: Vous avez modifié les notifications!';
$_['text_list']        = 'Liste des notifications';

// Column
$_['column_message']   = 'Message';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier les notifications!';
