<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'مجموعات الفلاتر';

// Text
$_['text_success']      = 'تم بنجاح: لقد قمت بتعديل مجموعات الفلاتر!';
$_['text_list']         = 'قائمة مجموعات الفلاتر';
$_['text_add']          = 'إضافة مجموعة فلتر';
$_['text_edit']         = 'تعديل مجموعة فلتر';

// Column
$_['column_name']       = 'اسم مجموعة الفلاتر';
$_['column_sort_order'] = 'ترتيب الفرز';
$_['column_action']     = 'تحرير';

// Entry
$_['entry_name']        = 'اسم مجموعة الفلاتر';
$_['entry_sort_order']  = 'ترتيب الفرز';

// Error
$_['error_warning']     = 'تحذير: يرجى التحقق من النموذج بعناية بحثًا عن الأخطاء!';
$_['error_permission']  = 'تحذير: ليس لديك إذن لتعديل مجموعات الفلاتر!';
$_['error_name']        = 'يجب أن يكون اسم مجموعة الفلاتر بين 1 و 64 حرفًا!';
$_['error_filter']      = 'تحذير: لا يمكن حذف هذه المجموعة لأنها مرتبطة بـ %s فلترًا!';
