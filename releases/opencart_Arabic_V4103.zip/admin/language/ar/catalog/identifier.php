<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'المعرّفات';

// Text
$_['text_success']     = 'تم بنجاح: لقد قمت بتعديل المعرّفات!';
$_['text_list']        = 'قائمة المعرّفات';
$_['text_add']         = 'إضافة معرّف';
$_['text_edit']        = 'تعديل معرّف';
$_['text_regex']       = 'التعبير النمطي (Regex)';

// Column
$_['column_name']      = 'اسم المعرّف';
$_['column_code']      = 'الرمز';
$_['column_action']    = 'إجراء';

// Entry
$_['entry_name']       = 'اسم المعرّف';
$_['entry_code']       = 'الرمز';
$_['entry_validation'] = 'التحقق';
$_['entry_status']     = 'الحالة';

// Help
$_['help_name']        = 'مثال: رمز تعريف المخزون (SKU)، الرمز العالمي للمنتج (UPC)، الرقم الأوروبي للمقالة (EAN)، الرقم الياباني للمقالة (JAN)، الرقم الدولي المعياري للكتاب (ISBN) أو رقم جزء الشركة المصنعة (MPN)';
$_['help_code']        = 'مثال: SKU، UPC، EAN، JAN، ISBN أو MPN';
$_['help_regex']       = 'استخدم التعبير النمطي (Regex)، مثال: /[^a-zA-Z0-9_-]/';
$_['help_status']      = 'عرض معرّف المنتج في صفحة معلومات المنتج';

// Error
$_['error_warning']    = 'تحذير: يرجى التحقق من النموذج بعناية لوجود أخطاء!';
$_['error_permission'] = 'تحذير: ليس لديك صلاحية لتعديل المعرّفات!';
$_['error_name']       = 'يجب أن يكون اسم المعرّف بين 1 و 64 حرفًا!';
$_['error_code']       = 'يجب أن يكون رمز المعرّف بين 3 و 48 حرفًا!';

