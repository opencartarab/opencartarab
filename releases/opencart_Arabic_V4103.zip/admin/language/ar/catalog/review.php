<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'التقييم';

// Text
$_['text_success']      = 'تم بنجاح: لقد قمت بتعديل التقييمات!';
$_['text_next']         = 'تم بنجاح: لقد قمت بتعديل %s إلى %s من %s تقييمات المنتجات!';
$_['text_list']         = 'قائمة التقييمات';
$_['text_add']          = 'إضافة تقييم';
$_['text_edit']         = 'تعديل تقييم';
$_['text_filter']       = 'فلتر';

// Column
$_['column_product']    = 'المنتج';
$_['column_author']     = 'الكاتب';
$_['column_rating']     = 'التصنيف';
$_['column_status']     = 'الحالة';
$_['column_date_added'] = 'تاريخ الاضافة';
$_['column_action']     = 'تحرير';

// Entry
$_['entry_product']     = 'المنتج';
$_['entry_author']      = 'الكاتب';
$_['entry_rating']      = 'التقييم';
$_['entry_status']      = 'الحالة';
$_['entry_text']        = 'النص';
$_['entry_date_added']  = 'تاريخ الإضافة';
$_['entry_date_from']   = 'التاريخ من';
$_['entry_date_to']     = 'التاريخ إلى';

// Help
$_['help_product']      = '(اكتب بداية حرف أي كلمة لتظهر القائمة المنسدلة للاستكمال التلقائي)';

// Button
$_['button_rating']     = 'مزامنة تقييمات المنتج';

// Error
$_['error_warning']     = 'تحذير: الرجاء مراجعة الخانات الخاطئة بعناية !';
$_['error_permission']  = 'تحذير: أنت لا تمتلك صلاحيات التعديل!';
$_['error_product']     = 'المنتج مطلوب!';
$_['error_author']      = 'اسم الكاتب يجب أن يكون بين 3 و 64 رمزاً!';
$_['error_text']        = 'نص التقييم يجب أن يكون على الأقل 1 رمزاً!';
$_['error_rating']      = 'التقييم مطلوب!';
