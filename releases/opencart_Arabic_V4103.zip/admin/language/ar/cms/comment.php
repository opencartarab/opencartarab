<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'تعليقات المقالات';

// Text
$_['text_success']     = 'تم بنجاح: لقد قمت بتعديل تعليقات المقالات!';
$_['text_next']        = 'تم بنجاح: لقد قمت بتعديل %s إلى %s من %s تقييمات التعليقات!';
$_['text_list']        = 'قائمة تعليقات المقالات';
$_['text_filter']      = 'فلتر';
$_['text_by']          = 'بواسطة';
$_['text_info']        = 'معلومات التعليق';
$_['text_rating']      = 'التقييم:';

// Column
$_['column_comment']   = 'التعليق';
$_['column_action']    = 'تحرير';

// Entry
$_['entry_keyword']    = 'الكلمة المفتاحية';
$_['entry_article']    = 'المقال';
$_['entry_customer']   = 'العميل';
$_['entry_status']     = 'الحالة';
$_['entry_date_from']  = 'التاريخ من';
$_['entry_date_to']    = 'التاريخ إلى';

// Button
$_['button_spam']      = 'كلمات غير مرغوب فيها';
$_['button_rating']    = 'حساب التقييمات';

// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن لتعديل تعليقات المقالات!';