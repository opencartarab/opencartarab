<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']            = 'هل نسيت كلمة المرور؟';
$_['heading_reset']            = 'إعادة تعيين كلمة المرور';

// Text
$_['text_email']               = 'أدخل عنوان البريد الإلكتروني المرتبط بحسابك. انقر على إرسال لتلقي رابط إعادة تعيين كلمة المرور عبر البريد الإلكتروني.';
$_['text_success']             = 'تم إرسال بريد إلكتروني مع رابط التأكيد إلى عنوان بريدك الإلكتروني الإداري.';
$_['text_password']            = 'أدخل كلمة المرور الجديدة التي ترغب في استخدامها.';
$_['text_reset']               = 'تم التعديل بنجاح: تم تحديث كلمة المرور بنجاح.';

// Entry
$_['entry_password']           = 'كلمة المرور الجديدة';
$_['entry_confirm']            = 'تأكيد كلمة المرور الجديدة';
$_['entry_email']              = 'عنوان البريد الإلكتروني';

// Error
$_['error_email']              = 'تحذير: لم يتم العثور على عنوان البريد الإلكتروني في سجلاتنا!';
$_['error_code']               = 'رمز إعادة التعيين غير مطابق!';
$_['error_disabled']           = 'تم تعطيل إعادة تعيين كلمة المرور!';
$_['error_password']           = 'يجب أن تحتوي كلمة المرور على %s وأن يكون طولها بين %d و 20 حرفًا!';
$_['error_password_uppercase'] = 'حرف كبير (Uppercase)';
$_['error_password_lowercase'] = 'حرف صغير (Lowercase)';
$_['error_password_number']    = 'رقم (Number)';
$_['error_password_symbol']    = 'رمز خاص (Symbol)';
$_['error_password_length']    = 'يجب أن يكون طول كلمة المرور بين %d و 40 حرفًا!';
$_['error_confirm']            = 'كلمة المرور وتأكيد كلمة المرور غير متطابقتين!';

