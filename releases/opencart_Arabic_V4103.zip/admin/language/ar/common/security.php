<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']                   = 'إشعار أمني هام!';

// Text
$_['text_install']                    = 'حذف مجلد التثبيت';
$_['text_install_description']        = 'يجب حذف مجلد التثبيت الخاص بك!';
$_['text_install_success']            = 'تم التعديل بنجاح: تم حذف مجلد التثبيت!';
$_['text_storage']                    = 'نقل مجلد التخزين Storage';
$_['text_storage_description']        = 'من المهم جدًا أن تنقل مجلد التخزين خارج مجلد الويب (مثل public_html، www أو htdocs).';
$_['text_storage_move']               = 'نقل %s إلى %s من %s ملفات التخزين Storage';
$_['text_storage_success']            = 'تم التعديل بنجاح: تم نقل مجلد التخزين Storage!';
$_['text_storage_delete']             = 'حذف مجلد التخزين السابق';
$_['text_storage_delete_description'] = 'يجب حذف مجلد التخزين السابق!';
$_['text_storage_delete_success']     = 'تم التعديل بنجاح: تم حذف مجلد التخزين السابق!';
$_['text_admin']                      = 'نقل مجلد الأدمن';
$_['text_admin_description']          = 'يرجى إدخال اسم جديد لمجلد الأدمن في الحقل أدناه.';
$_['text_admin_move']                 = 'نقل %s إلى %s من %s ملفات الأدمن';
$_['text_admin_success']              = 'تم التعديل بنجاح: تم نقل مجلد الأدمن!';
$_['text_admin_delete']               = 'حذف مجلد الأدمن السابق';
$_['text_admin_delete_description']   = 'يجب حذف مجلد الأدمن السابق!';
$_['text_admin_delete_success']       = 'تم التعديل بنجاح: تم حذف مجلد الأدمن السابق!';
$_['text_path']                       = 'المسار';

// Entry
$_['entry_path']                      = 'المسار';
$_['entry_path_current']              = 'المسار الحالي';
$_['entry_path_new']                  = 'المسار الجديد';
$_['entry_name']                      = 'اسم المجلد';

// Buttons
$_['button_move']                     = 'نقل';

// Help
$_['help_storage']                    = 'يجب أن يبدأ اسم مجلد التخزين بـ storage. مثل `storage_`.';

// Error
$_['error_permission']                = 'تحذير: ليس لديك صلاحية لتعديل الأمان!';
$_['error_install']                   = 'تحذير: مجلد التثبيت غير موجود!';
$_['error_storage']                   = 'تحذير: مجلد التخزين غير موجود!';
$_['error_storage_root']              = 'تحذير: يجب أن يكون مجلد التخزين خارج جذر الويب!';
$_['error_storage_name']              = 'تحذير: يجب أن يبدأ اسم مجلد التخزين بـ `storage`! مثل `storage_`.';
$_['error_admin']                     = 'تحذير: مجلد الأدمن غير موجود!';
$_['error_admin_allowed']             = 'تحذير: لا يمكن استخدام اسم مجلد الأدمن هذا!';
$_['error_admin_exists']              = 'تحذير: مجلد الأدمن موجود بالفعل!';
$_['error_writable']                  = 'تحذير: يجب جعل الملفات config.php و admin/config.php قابلة للكتابة!';
$_['error_remove']                    = 'تحذير: لا يوجد مجلد للحذف!';

