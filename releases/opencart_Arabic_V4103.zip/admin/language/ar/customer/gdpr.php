<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'موافقات GDPR';

// Text
$_['text_success']      = 'تم التعديل بنجاح: تم تعديل موافقات GDPR!';
$_['text_list']         = 'قائمة موافقات GDPR';
$_['text_info']         = '<strong>GDPR</strong> طلبات حذف الحسابات ستتم معالجتها بعد <strong>%s يومًا</strong> بحيث يمكن معالجة أي اكتشافات احتيال، استردادات، أو عمليات استرجاع.';
$_['text_approve']      = 'موافقة';
$_['text_deny']         = 'رفض';
$_['text_delete']       = 'حذف';
$_['text_unverified']   = 'غير موثق';
$_['text_pending']      = 'قيد الانتظار';
$_['text_processing']   = 'قيد المعالجة';
$_['text_complete']     = 'مكتمل';
$_['text_denied']       = 'مرفوض';
$_['text_export']       = 'تصدير';
$_['text_remove']       = 'إزالة';
$_['text_filter']       = 'تصفية';

// Column
$_['column_email']      = 'البريد الإلكتروني';
$_['column_request']    = 'الطلب';
$_['column_status']     = 'الحالة';
$_['column_date_added'] = 'تاريخ الإضافة';
$_['column_action']     = 'تحرير';

// Entry
$_['entry_email']       = 'البريد الإلكتروني';
$_['entry_action']      = 'تحرير';
$_['entry_status']      = 'الحالة';
$_['entry_date_from']   = 'التاريخ من';
$_['entry_date_to']     = 'التاريخ إلى';

// Error
$_['error_permission']  = 'تحذير: ليس لديك صلاحية لتعديل موافقات GDPR!';

