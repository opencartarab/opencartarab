<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']           = 'روابط السيو';

// Text
$_['text_success']            = 'نجاح: تم تعديل روابط السيو!';
$_['text_list']               = 'قائمة روابط السيو';
$_['text_add']                = 'إضافة رابط السيو';
$_['text_edit']               = 'تعديل رابط السيو';
$_['text_filter']             = 'تصفية';
$_['text_default']            = 'افتراضي';

// Column
$_['column_key']              = 'المفتاح';
$_['column_value']            = 'القيمة';
$_['column_keyword']          = 'الكلمة المفتاحية';
$_['column_sort_order']       = 'ترتيب الفرز';
$_['column_store']            = 'المتجر';
$_['column_language']         = 'اللغة';
$_['column_action']           = 'تحرير';

// Entry
$_['entry_store']             = 'المتجر';
$_['entry_language']          = 'اللغة';
$_['entry_key']               = 'المفتاح';
$_['entry_value']             = 'القيمة';
$_['entry_keyword']           = 'الكلمة المفتاحية';
$_['entry_sort_order']        = 'ترتيب الفرز';

// Help
$_['help_keyword']            = 'تأكد من استخدام الأحرف من a-z أو 0-9 فقط واستخدام - أو _ للمسافات. استخدم / للفئات.';
$_['help_sort_order']         = 'ترتيب الفرز للكلمات المفتاحية في رابط السيو.';

// Error
$_['error_permission']        = 'تحذير: ليس لديك إذن لتعديل روابط السيو!';
$_['error_exists']            = 'تحذير: مجموعة المتجر، اللغة، المفتاح، القيمة والكلمة المفتاحية موجودة بالفعل!';
$_['error_key']               = 'المفتاح يجب أن يكون بين 1 و 64 حرفًا!';
$_['error_value']             = 'القيمة يجب أن تكون بين 1 و 255 حرفًا!';
$_['error_value_exists']      = 'القيمة مستخدمة بالفعل!';
$_['error_keyword']           = 'الكلمة المفتاحية يجب أن تكون بين 1 و 64 حرفًا!';
$_['error_keyword_exists']    = 'الكلمة المفتاحية مستخدمة بالفعل!';
$_['error_keyword_character'] = 'الكلمة المفتاحية يمكن أن تحتوي فقط على الأحرف a-z و 0-9 و - و _!';

