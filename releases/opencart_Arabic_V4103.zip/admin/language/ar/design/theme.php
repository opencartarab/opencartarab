<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'محرر القوالب';

// Text
$_['text_success']      = 'نجاح: تم تعديل القوالب!';
$_['text_add']          = 'إضافة قالب';
$_['text_edit']         = 'تعديل القالب';
$_['text_default']      = 'افتراضي';
$_['text_extension']    = 'الإضافات';
$_['text_code']         = 'محرر كود القالب';
$_['text_twig']         = 'يستخدم محرر القوالب لغة القوالب Twig. يمكنك قراءة عن <a href="https://twig.symfony.com/doc/" target="_blank" class="alert-link">صيغة Twig هنا</a>.';

// Column
$_['column_store']      = 'المتجر';
$_['column_route']      = 'المسار';
$_['column_status']     = 'الحالة';
$_['column_date_added'] = 'تاريخ الإضافة';
$_['column_action']     = 'تحرير';

// Entry
$_['entry_store']       = 'المتجر';
$_['entry_route']       = 'اختيار القالب';
$_['entry_code']        = 'الكود';
$_['entry_status']      = 'الحالة';

// Error
$_['error_permission']  = 'تحذير: ليس لديك إذن لتعديل محرر القوالب!';
$_['error_file']        = 'تحذير: ملف القالب غير موجود!';

