<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'اللغات';

// Text
$_['text_success']     = 'نجاح: تم تعديل اللغات !';
$_['text_list']        = 'قائمة اللغات';

// Column
$_['column_name']      = 'اسم اللغة';
$_['column_status']    = 'الحالة';
$_['column_action']    = 'تحرير';

// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن لتعديل اللغات!';
$_['error_extension']  = 'تحذير: الإضافة غير موجودة!';
$_['error_default']    = 'تحذير: لا يمكن إلغاء تثبيت هذه الإضافة لأنها مخصصة حاليًا كلغة الإدارة!';
