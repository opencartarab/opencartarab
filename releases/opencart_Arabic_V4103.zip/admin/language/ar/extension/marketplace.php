<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'سوق الإضافات';

// Text
$_['text_success']     = 'تم بنجاح: لقد قمت بتعديل سوق الإضافات!';
$_['text_list']        = 'قائمة سوق الإضافات';

// Column
$_['column_name']      = 'اسم سوق الإضافات';
$_['column_status']    = 'الحالة';
$_['column_action']    = 'تحرير';

// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن لتعديل سوق الإضافات!';
$_['error_extension']  = 'تحذير: الامتداد غير موجود!';