<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'القوالب';

// Text
$_['text_success']     = 'تم تعديل القالب بنجاح !';
$_['text_list']        = 'قائمة القوالب';

// Column
$_['column_name']      = 'اسم القالب';
$_['column_status']    = 'الحالة';
$_['column_action']    = 'تحرير';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
$_['error_extension']  = 'تحذير: لم يتم العثور على الموديول !';
