<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'اللغة العربية';

// Text
$_['text_extension']   = 'الموديولات';
$_['text_success']     = 'تم تعديل اللغة العربية !';
$_['text_edit']        = 'تحرير اللغة العربية';

// Entry
$_['entry_status']     = 'الحالة';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات تعديل اللغة العربية !';