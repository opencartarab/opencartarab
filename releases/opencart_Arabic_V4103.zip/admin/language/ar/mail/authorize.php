<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject'] = 'الحماية';
$_['text_code']    = 'استخدم رمز الحماية في خانة التأكيد.';
$_['text_ip']      = 'رقم الآي بي :';
$_['text_regards'] = 'مع أطيب التحيات';
