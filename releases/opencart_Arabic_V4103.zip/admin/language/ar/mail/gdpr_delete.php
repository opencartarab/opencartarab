<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']   = '%s - تم معالجة طلب الـ GDPR!';
$_['text_request']   = 'طلب حذف الحساب';
$_['text_hello']     = 'مرحبًا <strong>%s</strong>,';
$_['text_user']      = 'المستخدم';
$_['text_delete']    = 'تم الآن إتمام طلب حذف بيانات الـ GDPR الخاصة بك.';
$_['text_contact']   = 'للحصول على مزيد من المعلومات، يمكنك الاتصال بمالك المتجر من هنا:';
$_['text_thanks']    = 'شكرًا,';

// Button
$_['button_contact'] = 'اتصل بنا';
