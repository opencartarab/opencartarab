<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']             = '%s - الاشتراك';
$_['text_subscription_id']     = 'معرف الإشتراك';
$_['text_date_added']          = 'تاريخ الاشتراك:';
$_['text_subscription_status'] = 'تمت إضافة اشتراكك إلى الحالة التالية:';
$_['text_comment']             = 'التعليقات على اشتراكك هي:';
$_['text_payment_method']      = 'طريقة الدفع او السداد';
$_['text_payment_code']        = 'رمز الدفع';
$_['text_footer']              = 'يرجى الرد على هذا البريد الإلكتروني إذا كان لديك أي أسئلة.';
