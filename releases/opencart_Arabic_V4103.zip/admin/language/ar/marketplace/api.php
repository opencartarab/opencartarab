<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'API سوق OpenCart';

// Text
$_['text_success']     = 'تم بنجاح: لقد قمت بتعديل معلومات API الخاصة بك!';
$_['text_signup']      = 'يرجى إدخال معلومات API الخاصة بـ OpenCart التي يمكنك الحصول عليها <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link">هنا</a>.';

// Entry
$_['entry_username']   = 'اسم المستخدم';
$_['entry_secret']     = 'الرمز السري';

// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن لتعديل API سوق OpenCart!';
$_['error_username']   = 'اسم المستخدم مطلوب!';
$_['error_secret']     = 'الرمز السري مطلوب!';


