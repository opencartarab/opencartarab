<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']        = 'المهام المجدولة CRON';

// Text
$_['text_success']         = 'تم بنجاح: لقد قمت بتعديل المهام المجدولة CRON!';
$_['text_instruction']     = 'تعليمات المهام المجدولة CRON';
$_['text_list']            = 'قائمة المهام المجدولة CRON';
$_['text_cron_1']          = 'المهام المجدولة CRON هي مهام مجدولة يتم تشغيلها بشكل دوري. لإعداد خوادمك لاستخدام المهام المجدولة CRON يمكنك قراءة <a href="http://docs.opencart.com/extension/cron/" target="_blank" class="alert-link">دليل OpenCart</a>.';
$_['text_cron_2']          = 'يجب عليك إعداد مهمة CRON الخاصة بك لتعمل كل ساعة.';
$_['text_info']            = 'معلومات المهام المجدولة CRON';
$_['text_hour']            = 'الساعة';
$_['text_day']             = 'اليوم';
$_['text_month']           = 'الشهر';

// Column
$_['column_code']          = 'كود المهام المجدولة CRON';
$_['column_cycle']         = 'الدورة';
$_['column_date_added']    = 'تاريخ الإضافة';
$_['column_date_modified'] = 'تاريخ التعديل';
$_['column_action']        = 'الإجراء';

// Entry
$_['entry_cron']           = 'رابط المهام المجدولة CRON';
$_['entry_description']    = 'الوصف';

// Error
$_['error_permission']     = 'تحذير: ليس لديك إذن لتعديل المهام المجدولة CRON!';

