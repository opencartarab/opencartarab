<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'سوق الإضافات';

// Text
$_['text_success']       = 'تم بنجاح: لقد قمت بتعديل الإضافات!';
$_['text_list']          = 'قائمة الإضافات';
$_['text_filter']        = 'تصفية';
$_['text_search']        = 'ابحث عن الإضافات والقوالب';
$_['text_category']      = 'الفئات';
$_['text_all']           = 'الكل';
$_['text_theme']         = 'القوالب';
$_['text_marketplace']   = 'الأسواق';
$_['text_language']      = 'اللغات';
$_['text_payment']       = 'الدفع';
$_['text_shipping']      = 'الشحن';
$_['text_module']        = 'الوحدات';
$_['text_total']         = 'إجمالي الطلب';
$_['text_feed']          = 'الخلاصات';
$_['text_report']        = 'التقارير';
$_['text_other']         = 'أخرى';
$_['text_free']          = 'مجاني';
$_['text_paid']          = 'مدفوع';
$_['text_purchased']     = 'تم الشراء';
$_['text_recommended']   = 'مستحسن';
$_['text_date_modified'] = 'تاريخ التعديل';
$_['text_date_added']    = 'تاريخ الإضافة';
$_['text_rating']        = 'التقييم';
$_['text_reviews']       = 'المراجعات';
$_['text_compatibility'] = 'التوافق';
$_['text_downloaded']    = 'تم التنزيل';
$_['text_member_since']  = 'عضو منذ:';
$_['text_price']         = 'السعر';
$_['text_featured']      = 'مميز';
$_['text_partner']       = 'مطور من قبل شريك OpenCart';
$_['text_support']       = 'دعم مجاني لمدة 12 شهراً';
$_['text_documentation'] = 'الوثائق المرفقة';
$_['text_sales']         = 'المبيعات';
$_['text_comment']       = 'التعليقات';
$_['text_download']      = 'التنزيل';
$_['text_install']       = 'التثبيت';
$_['text_comment_add']   = 'أضف تعليقك';
$_['text_write']         = 'اكتب تعليقك هنا.';
$_['text_purchase']      = 'يرجى تأكيد هويتك!';
$_['text_pin']           = 'يرجى إدخال رقم الـ PIN المكون من 4 أرقام. هذا الرقم لحماية حسابك.';
$_['text_secure']        = 'لا تعطي رقم الـ PIN لأحد (بما في ذلك المطورين). إذا كنت بحاجة إلى المساعدة، يرجى إرسال بريد إلكتروني إلى بائع الإضافة بخصوص حزمة الإضافة المحددة.';
$_['text_name']          = 'اسم التنزيل';
$_['text_available']     = 'التنصيبات المتاحة';
$_['text_action']        = 'تحرير';
$_['text_install']       = 'تثبيت';
$_['text_uninstall']     = 'إلغاء التثبيت';
$_['text_delete']        = 'حذف';
$_['text_more']          = 'شاهد المزيد من الردود...';
$_['text_refresh']       = 'تحديث';

// Entry
$_['entry_pin']          = 'رقم الـ PIN';

// Tabs
$_['tab_description']    = 'الوصف';
$_['tab_documentation']  = 'الوثائق';
$_['tab_download']       = 'التنزيل';
$_['tab_comment']        = 'التعليق';

// Buttons
$_['button_api']         = 'API سوق الإضافات';
$_['button_purchase']    = 'شراء';
$_['button_view_all']    = 'عرض جميع الإضافات';
$_['button_support']     = 'احصل على الدعم';
$_['button_comment']     = 'التعليق';
$_['button_reply']       = 'الرد';
$_['button_forgot_pin']  = 'هل نسيت رقم الـ PIN؟';

// Error
$_['error_permission']   = 'تحذير: ليس لديك إذن لتعديل الإضافات!';
$_['error_api']          = 'تحذير: يجب إدخال معلومات API الخاصة بـ OpenCart بالنقر على <i class="fa-solid fa-triangle-exclamation"></i> قبل أن تتمكن من تنزيل الإضافات أو إجراء أي عمليات شراء!';
$_['error_purchase']     = 'تعذر شراء الإضافة!';
$_['error_download']     = 'تعذر تنزيل الإضافة!';

