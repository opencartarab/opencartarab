<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']             = 'إرجاع الطلب';

// Text
$_['text_success']              = 'تم بنجاح: لقد قمت بتعديل عمليات الإرجاع!';
$_['text_list']                 = 'قائمة الإرجاع';
$_['text_add']                  = 'إضافة إرجاع';
$_['text_edit']                 = 'إرجاع (#%s)';
$_['text_order_id']             = 'رقم الطلب';
$_['text_filter']               = 'تصفية';
$_['text_customer']             = 'العميل';
$_['text_date_added']           = 'تاريخ الإضافة';
$_['text_return']               = 'منتج للإرجاع';
$_['text_product']              = 'اختر المنتج للإرجاع';
$_['text_opened']               = 'مفتوح';
$_['text_unopened']             = 'غير مفتوح';
$_['text_history']              = 'التاريخ';
$_['text_history_add']          = 'إضافة تاريخ';

// Column
$_['column_return_id']          = 'رقم الإرجاع';
$_['column_order_id']           = 'رقم الطلب';
$_['column_customer']           = 'العميل';
$_['column_product']            = 'المنتج';
$_['column_model']              = 'الطراز';
$_['column_quantity']           = 'الكمية';
$_['column_status']             = 'الحالة';
$_['column_date_added']         = 'تاريخ الإضافة';
$_['column_comment']            = 'التعليق';
$_['column_notify']             = 'تم إعلام العميل';
$_['column_action']             = 'تحرير';

// Entry
$_['entry_customer']            = 'العميل';
$_['entry_order_id']            = 'رقم الطلب';
$_['entry_date_ordered']        = 'تاريخ الطلب';
$_['entry_firstname']           = 'الاسم الأول';
$_['entry_lastname']            = 'الاسم الأخير';
$_['entry_email']               = 'البريد الإلكتروني';
$_['entry_telephone']           = 'رقم التواصل';
$_['entry_product']             = 'المنتج';
$_['entry_model']               = 'الطراز';
$_['entry_quantity']            = 'الكمية';
$_['entry_opened']              = 'مفتوح';
$_['entry_comment']             = 'التعليق';
$_['entry_return_reason']       = 'سبب الإرجاع';
$_['entry_return_action']       = 'إجراء الإرجاع';
$_['entry_return_status']       = 'حالة الإرجاع';
$_['entry_return_id']           = 'رقم الإرجاع';
$_['entry_notify']              = 'إعلام العميل';
$_['entry_date_from']           = 'التاريخ من';
$_['entry_date_to']             = 'التاريخ إلى';

// Help
$_['help_product']              = '(إكمال تلقائي)';

// Error
$_['error_warning']             = 'تحذير: يرجى التحقق من النموذج بعناية بحثًا عن الأخطاء!';
$_['error_permission']          = 'تحذير: ليس لديك إذن لتعديل عمليات الإرجاع!';
$_['error_order']               = 'الطلب غير موجود!';
$_['error_customer']            = 'العميل غير موجود!';
$_['error_firstname']           = 'يجب أن يتراوح الاسم الأول بين 1 و 32 حرفًا!';
$_['error_lastname']            = 'يجب أن يتراوح الاسم الأخير بين 1 و 32 حرفًا!';
$_['error_email']               = 'عنوان البريد الإلكتروني لا يبدو صالحًا!';
$_['error_telephone']           = 'يجب أن يتراوح رقم التواصل بين 3 و 32 حرفًا!';
$_['error_product']             = 'المنتج غير موجود!';
$_['error_name']                = 'يجب أن يكون اسم المنتج أكبر من 1 وأقل من 255 حرفًا!';
$_['error_model']               = 'يجب أن يكون موديل المنتج أكبر من 1 وأقل من 64 حرفًا!';
$_['error_quantity']            = 'يجب أن تكون الكمية للإرجاع على الأقل 1!';
$_['error_reason']              = 'يجب اختيار سبب الإرجاع!';
$_['error_action']              = 'يجب اختيار إجراء الإرجاع!';
