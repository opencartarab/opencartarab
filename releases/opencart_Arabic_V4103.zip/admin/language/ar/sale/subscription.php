<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']              = 'خطط الاشتراكات';

// Text
$_['text_success']               = 'تم بنجاح: لقد قمت بتعديل الاشتراكات!';
$_['text_list']                  = 'قائمة الاشتراكات';
$_['text_add']                   = 'إضافة اشتراك';
$_['text_edit']                  = 'اشتراك (#%s)';
$_['text_filter']                = 'تصفية';
$_['text_date_added']            = 'تاريخ الإضافة';
$_['text_order_id']              = 'رقم الطلب';
$_['text_order']                 = 'الطلبات';
$_['text_product_add']           = 'إضافة منتج';
$_['text_model'] 			     = 'الموديل';
$_['text_subscription']          = 'الاشتراك';
$_['text_date_next']             = 'التاريخ التالي';
$_['text_remaining']             = 'المتبقي';
$_['text_subscription_trial']    = '%s كل %d %s(s) لمدة %d دفعة(s) ثم ';
$_['text_subscription_duration'] = '%s كل %d %s(s) لمدة %d دفعة(s)';
$_['text_subscription_cancel']   = '%s كل %d %s(s) حتى يتم الإلغاء';
$_['text_cancel']                = 'حتى يتم الإلغاء';
$_['text_day']                   = 'يوم';
$_['text_week']                  = 'أسبوع';
$_['text_semi_month']            = 'نصف شهر';
$_['text_month']                 = 'شهر';
$_['text_year']                  = 'سنة';
$_['text_payment_method']        = 'طريقة الدفع';
$_['text_payment']               = 'يرجى اختيار طريقة الدفع المفضلة للاشتراك.';
$_['text_shipping_method']       = 'طريقة الشحن';
$_['text_shipping']              = 'يرجى اختيار طريقة الشحن المفضلة للاشتراك.';
$_['text_history']               = 'التاريخ';
$_['text_history_add']           = 'إضافة تاريخ';
$_['text_log']                   = 'السجلات';

// Column
$_['column_subscription_id']     = 'رقم الاشتراك';
$_['column_order_id']            = 'رقم الطلب';
$_['column_customer']            = 'العميل';
$_['column_comment']             = 'التعليق';
$_['column_notify']              = 'تم إعلام العميل';
$_['column_status']              = 'الحالة';
$_['column_date_added']          = 'تاريخ الإضافة';
$_['column_product']             = 'المنتج';
$_['column_model']               = 'الموديل';
$_['column_quantity']            = 'الكمية';
$_['column_trial_price']         = 'سعر التجربة';
$_['column_price']               = 'السعر';
$_['column_total']               = 'الاجمالي';
$_['column_amount']              = 'المبلغ';
$_['column_code']                = 'الكود';
$_['column_description']         = 'الوصف';
$_['column_action']              = 'الإجراء';

// Entry
$_['entry_subscription_id']      = 'رقم الاشتراك';
$_['entry_order_id']             = 'رقم الطلب';
$_['entry_customer']             = 'العميل';
$_['entry_store']                = 'المتجر';
$_['entry_language']             = 'اللغة';
$_['entry_currency']             = 'العملة';
$_['entry_subscription_plan']    = 'خطة الاشتراك';
$_['entry_date_next']            = 'التاريخ التالي';
$_['entry_comment']              = 'التعليق';
$_['entry_notify']               = 'إعلام العميل';
$_['entry_date_from']            = 'التاريخ من';
$_['entry_date_to']              = 'التاريخ إلى';
$_['entry_subscription_status']  = 'حالة الاشتراك';
$_['entry_product']              = 'اختر المنتج';
$_['entry_option']               = 'اختر الخيار(s)';
$_['entry_quantity']             = 'الكمية';
$_['entry_payment_address']      = 'عنوان الدفع';
$_['entry_shipping_address']     = 'عنوان الشحن';

// Tab
$_['tab_order']                  = 'الطلبات';

// Error
$_['error_permission']           = 'تحذير: ليس لديك إذن لتعديل الاشتراكات!';
$_['error_subscription_status']  = 'تحذير: يجب تحديد حالة الاشتراك!';
$_['error_payment_method']       = 'تحذير: طريقة الدفع غير موجودة!';
$_['error_subscription']         = 'تنبيه: لم يتم إضافة الاشتراك بعد!';