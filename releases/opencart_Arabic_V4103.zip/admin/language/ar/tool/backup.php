<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'النسخ الاحتياطي والاستعادة';

// Text
$_['text_success']       = 'نجاح: لقد قمت بتعديل قاعدة البيانات بنجاح!';
$_['text_progress']      = 'تقدم النسخ الاحتياطي';
$_['text_backup']        = 'نسخ جدول %s السجلات %s إلى %s السجلات';
$_['text_restore']       = 'استعادة %s من %s';
$_['text_option']        = 'خيارات النسخ الاحتياطي';
$_['text_history']       = 'تاريخ النسخ الاحتياطي';
$_['text_import']        = 'لملفات النسخ الاحتياطي الكبيرة من الأفضل رفع ملف SQL عبر FTP إلى مجلد <strong>~/storage/backup/</strong>.';

// Column
$_['column_filename']    = 'اسم الملف';
$_['column_size']        = 'الحجم';
$_['column_date_added']  = 'تاريخ الإضافة';
$_['column_action']      = 'تحرير';

// Entry
$_['entry_progress']     = 'التقدم';
$_['entry_export']       = 'التصدير';

// Error
$_['error_permission']   = 'تحذير: ليس لديك إذن لتعديل النسخ الاحتياطي والاستعادة!';
$_['error_export']       = 'تحذير: يجب عليك اختيار جدول واحد على الأقل للتصدير!';
$_['error_table']        = 'الجدول %s غير موجود في القائمة المسموح بها!';
$_['error_file']         = 'تعذر العثور على الملف!';
$_['error_directory']    = 'تعذر العثور على المجلد!';
$_['error_not_found']    = 'خطأ: تعذر العثور على الملف %s!';
$_['error_headers_sent'] = 'خطأ: تم إرسال الرؤوس بالفعل!';
$_['error_upload_size']  = 'لا يمكن أن يكون حجم الملف المرفوع أكبر من %s!';
