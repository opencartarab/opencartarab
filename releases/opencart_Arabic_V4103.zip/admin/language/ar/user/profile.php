<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']            = 'الملف الشخصي';

// Text
$_['text_success']             = 'نجاح: لقد قمت بتعديل ملفك الشخصي بنجاح!';
$_['text_edit']                = 'تعديل ملفك الشخصي';
$_['text_user']                = 'تفاصيل المستخدم';
$_['text_password']            = 'كلمة المرور';

// Entry
$_['entry_username']           = 'اسم المستخدم';
$_['entry_password']           = 'كلمة المرور';
$_['entry_confirm']            = 'تأكيد كلمة المرور';
$_['entry_firstname']          = 'الاسم الأول';
$_['entry_lastname']           = 'اسم العائلة';
$_['entry_email']              = 'البريد الإلكتروني';
$_['entry_image']              = 'الصورة';

// Error
$_['error_permission']         = 'تحذير: ليس لديك إذن لتعديل ملفك الشخصي!';
$_['error_username_exists']    = 'تحذير: اسم المستخدم مستخدم بالفعل!';
$_['error_username']           = 'اسم المستخدم يجب أن يكون بين 3 و 20 حرفًا!';
$_['error_firstname']          = 'الاسم الأول يجب أن يكون بين 1 و 32 حرفًا!';
$_['error_lastname']           = 'اسم العائلة يجب أن يكون بين 1 و 32 حرفًا!';
$_['error_email']              = 'عنوان البريد الإلكتروني لا يبدو صالحًا!';
$_['error_email_exists']       = 'تحذير: عنوان البريد الإلكتروني مسجل بالفعل!';
$_['error_password']           = 'يجب أن تحتوي كلمة المرور على %s وأن يكون طولها بين %d و 20 حرفًا!';
$_['error_password_uppercase'] = 'حرف كبير (Uppercase)';
$_['error_password_lowercase'] = 'حرف صغير (Lowercase)';
$_['error_password_number']    = 'رقم (Number)';
$_['error_password_symbol']    = 'رمز خاص (Symbol)';
$_['error_password_length']    = 'يجب أن يكون طول كلمة المرور بين %d و 20 حرفًا!';
$_['error_confirm']            = 'كلمة المرور وتأكيدها غير متطابقين!';

