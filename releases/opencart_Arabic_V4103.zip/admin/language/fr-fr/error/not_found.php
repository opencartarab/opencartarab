<?php
// En-tête
$_['heading_title']  = 'Page Introuvable!';

// Texte
$_['text_not_found'] = 'La page que vous recherchez est introuvable! Veuillez contacter votre administrateur si le problème persiste.';
