<?php
// En-tête
$_['heading_title']    = 'Autres';

// Texte
$_['text_success']     = 'Succès: Vous avez modifié une autre extension!';
$_['text_list']        = 'Liste des autres extensions';

// Colonne
$_['column_name']      = 'Nom de l\'autre extension';
$_['column_status']    = 'Statut';
$_['column_action']    = 'Action';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'êtes pas autorisé à modifier une autre extension!';
$_['error_extension']  = 'Attention: L\'extension n\'existe pas!';
