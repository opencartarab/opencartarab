<?php
// Texte
$_['text_subject'] = '%s - Votre compte a été activé!';
$_['text_welcome'] = 'Bienvenue et merci de vous être inscrit sur %s!';
$_['text_login']   = 'Votre compte a maintenant été créé et vous pouvez vous connecter en utilisant votre adresse e-mail et votre mot de passe en visitant notre site Web ou à l\'URL suivante:';
$_['text_service'] = 'Une fois connecté, vous pourrez accéder à d\'autres services, notamment consulter vos commandes passées, imprimer des factures et modifier vos informations de compte.';
$_['text_thanks']  = 'Merci,';

// Bouton
$_['button_login'] = 'Connexion';
