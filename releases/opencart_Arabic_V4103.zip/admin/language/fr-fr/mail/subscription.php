<?php
// Texte
$_['text_subject']             = '%s - Abonnement';
$_['text_subscription_id']     = 'ID d\'Abonnement';
$_['text_date_added']          = 'Date d\'Abonnement:';
$_['text_subscription_status'] = 'Votre abonnement a été mis à jour avec le statut suivant:';
$_['text_comment']             = 'Les commentaires concernant votre abonnement sont:';
$_['text_payment_method']      = 'Mode de Paiement';
$_['text_payment_code']        = 'Code de Paiement';
$_['text_footer']              = 'Veuillez répondre à cet e-mail si vous avez des questions.';
