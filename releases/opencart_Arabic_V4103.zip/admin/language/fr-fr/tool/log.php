<?php
// En-tête
$_['heading_title']    = 'Journal des erreurs';

// Texte
$_['text_success']     = 'Succès: Vous avez effacé avec succès votre journal des erreurs!';
$_['text_list']        = 'Liste des erreurs';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission d\'effacer le journal des erreurs!';
$_['error_file']       = 'Attention: Le fichier %s est introuvable!';
$_['error_size']       = 'Attention: Le fichier journal des erreurs %s est de taille %s!';
$_['error_empty']      = 'Attention: Le fichier journal %s est vide!';
